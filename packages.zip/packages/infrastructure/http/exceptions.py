# HTTP exceptions
