# Logging middleware
