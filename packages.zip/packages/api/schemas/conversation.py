# Schema conversation
