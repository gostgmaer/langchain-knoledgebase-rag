# AI response repository
